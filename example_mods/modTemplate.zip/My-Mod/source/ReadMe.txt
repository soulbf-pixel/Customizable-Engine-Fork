Put any .hx files here so it runs globally
(Example: Death Count)