Put your states .hx files here! (Remember to name it exactly like the following below)
(Available: ChartingState, CharacterEditorState, StoryMenuState, FreeplayState)
MORE TO COME